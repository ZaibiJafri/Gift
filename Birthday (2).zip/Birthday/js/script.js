document.addEventListener("DOMContentLoaded", function () {
    const dateElement = document.getElementById("date");
    const monthElement = document.getElementById("month");
    const wishesElement = document.getElementById("wishes");
    const countDownElement = document.getElementById("countDown");
    const birthdayHeading = document.getElementById("birthdayHeading");
    const birthdaySongAudio = document.getElementById("birthdaySongAudio");
    const video = document.getElementById("bgVideo");

    let birthdaySongPlayCount = 0;

    // Array of wishes messages, one for each day
    const wishesMessages = [
        "Wishing your day is filled with laughter, love, and unforgettable moments! 🎉💖",
        "May your birthday be a spectacular celebration, surrounded by joy and warmth! 🎂🌟",
        "Sending you heartfelt wishes for an extraordinary birthday! Enjoy every moment! 🥳🎈",
        "Cheers to a day filled with happiness, surprises, and all the things you love! 🎊🎁",
        "May your birthday be as fantastic and special as you are! Celebrate in style! 🎂✨",
        "Wishing you a day overflowing with love, laughter, and incredible memories! 🎉💕",
        "Happy Birthday! May your year ahead be as amazing and bright as your smile! 😊🌈",
        "Here's to another year of joy, growth, and all the wonderful things life offers! 🎂🌠",
        "May your birthday bring you immense joy, love, and everything your heart desires! 💖🎁",
        "Cheers to a year ahead filled with exciting adventures and beautiful moments! 🌟🎈",
        "Wishing you a day of laughter, love, and all the happiness in the world! 🎉💕",
        "Happy Birthday! May your day be as extraordinary and vibrant as you are! 🎂🌈",
        "May your special day be sprinkled with love, surrounded by loved ones, and pure joy! 💐🎊",
        "Here's to a year filled with new opportunities, beautiful surprises, and endless joy! 🎂💕",
        "Happy Birthday! May this year bring you success, happiness, and fulfillment! 🎂🌟",
        "Wishing you a day that's as incredible, unique, and special as you are! 🎉💖",
        "May your birthday be the start of a year filled with love, laughter, and success! 🥳🎁",
        "Happy Birthday! May your day be as bright, beautiful, and joyful as your spirit! 🎂✨",
        "Cheers to a new chapter filled with growth, happiness, and exciting adventures! 🌈🎈",
        "Wishing you a day of pure joy, surrounded by love, laughter, and cherished moments! 💕🎊",
        "Happy Birthday! May this year bring you endless opportunities and moments of pure joy! 🎉🌠",
        "May your birthday mark the beginning of a year filled with success, love, and prosperity! 💖🎉",
        "Cheers to a day that's all about you! May it be filled with joy, love, and special moments! 🎈🌟",
        "Wishing you a fantastic birthday surrounded by the love of friends, family, and laughter! 🎂💕",
        "Happy Birthday! May your day be filled with surprises, love, and unforgettable memories! 🎂✨",
        "May your birthday be a day of celebration, reflection, and the start of new dreams! 🎉💖",
        "Cheers to another year of wonderful experiences, personal growth, and joyous moments! 🥂🌈",
        "Wishing you a birthday filled with love, laughter, and all the things that make you happy! 😊🎁",
        "Happy Birthday! May your day be filled with joy, love, and all the happiness in the world! 🎂💖"
    ];


    const updateCountdown = () => {
        const currentDate = new Date();
        const birthdayDate = new Date("April 9, 2024 00:00:00");

        // Display the current date
        dateElement.textContent = currentDate.getDate();

        // Update the month dynamically
        const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
        const currentMonth = months[currentDate.getMonth()];

        monthElement.textContent = currentMonth;

        // Check if it's the birthday
        if (
            currentDate.getDate() === birthdayDate.getDate() &&
            currentDate.getMonth() === birthdayDate.getMonth()
        ) {
            wishesElement.textContent = "Happy Birthday! MY Dear Rani Sahiba 🎉🥳";
            countDownElement.textContent = "The big day is here!";
            birthdayHeading.classList.add("special");
            if (birthdaySongPlayCount < 2) {
                playBirthdaySong();
                birthdaySongPlayCount++;
            }
            bgVideo.style.display = "block";
        } else {
            // Calculate the remaining days, hours, minutes, and seconds
            const distance = birthdayDate - currentDate;
            const days = Math.floor(distance / (1000 * 60 * 60 * 24));
            const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((distance % (1000 * 60)) / 1000);

            bgVideo.style.display = "none";

            // Display the countdown
            countDownElement.textContent = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            // Display wishes based on the current date
            const dayIndex = currentDate.getDate() - 1;
            if (dayIndex < wishesMessages.length) {
                wishesElement.textContent = wishesMessages[dayIndex];
            } else {
                wishesElement.textContent = "Wishing you a wonderful day!";
            }

            // Adjust heading based on the remaining days
            const remainingDays = Math.ceil(distance / (1000 * 60 * 60 * 24));
            if (remainingDays > 1) {
                birthdayHeading.textContent = `Counting down to the big day! ${remainingDays} days to go!`;
                birthdayHeading.classList.add("waiting");
            } else {
                birthdayHeading.textContent = "Counting down to the big day!";
                birthdayHeading.classList.remove("waiting");
            }

            birthdayHeading.classList.remove("special");
        }
    };
    const playBirthdaySong = () => {
        try {
            // Check if the audio context is already running
            const context = new (window.AudioContext || window.webkitAudioContext)();
            if (context.state === 'suspended') {
                context.resume().then(() => {
                    // Load and play the birthday song
                    birthdaySongAudio.play();
                });
            } else {
                // Load and play the birthday song
                birthdaySongAudio.play();
            }
        } catch (error) {
            console.error("Error playing Birthday song:", error);
        }
    };
    

    // Initial call to display the current date and wishes immediately
    updateCountdown();

    // Update the date, wishes, and countdown every second
    setInterval(updateCountdown, 1000);
});